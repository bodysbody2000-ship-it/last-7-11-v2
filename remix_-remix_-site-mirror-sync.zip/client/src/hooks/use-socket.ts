import { useEffect, useRef, useState } from "react";
import { type WsMessage } from "@shared/schema";

interface PollResponse {
  state: any;
  students: any[];
  counters: any;
  photos: Record<number, string>;
  alerts: { id: number; type: string; payload: any; timestamp: number }[];
}

export function useSocket() {
  const [isConnected, setIsConnected] = useState(true);
  const listeners = useRef<Map<string, (payload: any) => void>>(new Map());
  const lastAlertId = useRef<number>(0);
  const lastStateStr = useRef<string>("");
  const lastStudentsStr = useRef<string>("");
  const lastCountersStr = useRef<string>("");
  const unmounted = useRef(false);

  useEffect(() => {
    unmounted.current = false;

    let pollInterval: ReturnType<typeof setInterval> | null = null;

    const doPoll = async () => {
      if (unmounted.current) return;
      try {
        const res = await fetch("/api/state");
        if (!res.ok) {
          throw new Error("Failed to poll state");
        }
        const data: PollResponse = await res.json();
        if (unmounted.current) return;

        setIsConnected(true);

        // 1. Dispatch State Update if changed
        const stateStr = JSON.stringify(data.state);
        if (stateStr !== lastStateStr.current) {
          lastStateStr.current = stateStr;
          const stateListener = listeners.current.get("STATE_UPDATE");
          if (stateListener && data.state) {
            stateListener(data.state);
          }
        }

        // 2. Dispatch Students Update if changed
        const studentsStr = JSON.stringify(data.students);
        if (studentsStr !== lastStudentsStr.current) {
          lastStudentsStr.current = studentsStr;
          const studentsListener = listeners.current.get("STUDENTS_UPDATE");
          if (studentsListener && data.students) {
            studentsListener(data.students);
          }
        }

        // 3. Dispatch Counters Update if changed
        const countersStr = JSON.stringify(data.counters);
        if (countersStr !== lastCountersStr.current) {
          lastCountersStr.current = countersStr;
          const countersListener = listeners.current.get("COUNTERS_UPDATE");
          if (countersListener && data.counters) {
            countersListener(data.counters);
          }
        }

        // 4. Dispatch Alerts (transient messages like TEACHER_ALERT, PHOTO_ADDED, KICK_STUDENT, etc.)
        if (data.alerts && Array.isArray(data.alerts)) {
          // If this is our very first poll, initialize lastAlertId so we don't trigger old alerts
          if (lastAlertId.current === 0) {
            if (data.alerts.length > 0) {
              lastAlertId.current = Math.max(...data.alerts.map(a => a.id));
            }
          } else {
            for (const alert of data.alerts) {
              if (alert.id > lastAlertId.current) {
                const listener = listeners.current.get(alert.type);
                if (listener) {
                  listener(alert.payload);
                }
                lastAlertId.current = alert.id;
              }
            }
          }
        }
      } catch (err) {
        console.error("Polling error:", err);
        setIsConnected(false);
      }
    };

    // Run first poll immediately
    doPoll();

    // Poll every 250ms (quarter of a second) as requested by the user
    pollInterval = setInterval(doPoll, 250);

    return () => {
      unmounted.current = true;
      if (pollInterval) clearInterval(pollInterval);
    };
  }, []);

  const onMessage = <T extends WsMessage['type']>(
    type: T,
    callback: (payload: Extract<WsMessage, { type: T }>['payload']) => void
  ) => {
    listeners.current.set(type, callback);
  };

  return { socket: null, isConnected, onMessage };
}

