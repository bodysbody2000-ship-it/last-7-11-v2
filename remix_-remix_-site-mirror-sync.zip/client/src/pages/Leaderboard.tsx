import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, Trophy, Search, Award, Flame, Target, CheckCircle2, User, RefreshCw } from "lucide-react";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { Input } from "@/components/ui/input";
import { Helmet } from "react-helmet-async";

interface PermanentStudent {
  email: string;
  name: string;
  score: number;
  photo?: string;
  consecutiveCorrect: number;
  totalAnswers: number;
  correctAnswersCount: number;
  lastUpdated: string;
}

export default function Leaderboard() {
  const [search, setSearch] = useState("");

  const { data: students = [], isLoading, refetch, isRefetching } = useQuery<PermanentStudent[]>({
    queryKey: ["/api/leaderboard"],
    queryFn: async () => {
      const res = await fetch("/api/leaderboard");
      if (!res.ok) throw new Error("Failed to load leaderboard");
      return res.json();
    }
  });

  const filteredStudents = students.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen p-4 md:p-8 relative">
      <Helmet>
        <title>لوحة الشرف والترتيبات - كيمياء مستر أحمد</title>
        <meta name="description" content="جدول الترتيبات ونقاط الطلاب الدائمة لمستر أحمد عبد الوهاب طوال السنة الدراسية." />
      </Helmet>
      <AnimatedBackground />

      {/* Back Button */}
      <Link href="/" className="absolute top-4 left-4 md:top-8 md:left-8 p-3 rounded-full bg-zinc-900/60 border border-white/10 hover:bg-zinc-800 transition-all text-white z-50 flex items-center justify-center shadow-xl">
        <ArrowLeft className="w-5 h-5" />
      </Link>

      <div className="max-w-4xl mx-auto space-y-8 pt-10 pb-20">
        {/* Title Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-3"
        >
          <div className="w-20 h-20 bg-gradient-to-tr from-amber-500 to-yellow-400 rounded-3xl flex items-center justify-center mx-auto shadow-[0_0_40px_rgba(245,158,11,0.3)] border border-yellow-400/30">
            <Trophy className="w-10 h-10 text-black" />
          </div>
          <h1 className="text-4xl md:text-6xl font-black bg-gradient-to-r from-amber-400 via-yellow-300 to-orange-400 bg-clip-text text-transparent drop-shadow-[0_4px_20px_rgba(245,158,11,0.2)]">
            لوحة الشرف الدائمة 🏆
          </h1>
          <p className="text-gray-400 text-lg max-w-lg mx-auto font-medium">
            ترتيب الأبطال ونقاطهم المتراكمة طوال العام الدراسي في مادة الكيمياء
          </p>
        </motion.div>

        {/* Search & Refresh */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex gap-3 max-w-xl mx-auto"
        >
          <div className="relative flex-1">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <Input
              type="text"
              placeholder="ابحث عن اسم البطل..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-14 pr-12 pl-4 text-lg bg-zinc-900/80 border-white/10 text-white rounded-2xl focus:ring-2 focus:ring-amber-500/50 text-right font-medium"
              dir="rtl"
            />
          </div>
          <button
            onClick={() => refetch()}
            disabled={isLoading || isRefetching}
            className="h-14 w-14 rounded-2xl bg-zinc-900/80 border border-white/10 hover:bg-zinc-800 transition-all text-white flex items-center justify-center shadow-xl hover:border-amber-500/30 disabled:opacity-50"
          >
            <RefreshCw className={`w-5 h-5 ${isRefetching ? "animate-spin" : ""}`} />
          </button>
        </motion.div>

        {/* Podium for top 3 (Horizontal on large screens, vertical on mobile) */}
        {!search && filteredStudents.length >= 1 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end pt-6"
            dir="rtl"
          >
            {/* 2nd Place */}
            {filteredStudents[1] && (
              <div className="bg-zinc-900/60 border border-zinc-700/50 rounded-[2.5rem] p-6 text-center order-2 md:order-1 relative shadow-2xl h-[260px] flex flex-col justify-between overflow-hidden">
                <div className="absolute top-0 inset-x-0 h-1.5 bg-gray-400" />
                <div>
                  <div className="relative w-20 h-20 mx-auto mb-3">
                    {filteredStudents[1].photo ? (
                      <img
                        src={filteredStudents[1].photo}
                        alt={filteredStudents[1].name}
                        className="w-full h-full rounded-2xl object-cover border-2 border-gray-400"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full rounded-2xl bg-zinc-800 flex items-center justify-center border-2 border-gray-400">
                        <User className="w-10 h-10 text-gray-400" />
                      </div>
                    )}
                    <span className="absolute -bottom-2 -left-2 bg-gray-400 text-black font-extrabold text-sm w-7 h-7 rounded-lg flex items-center justify-center shadow-md">
                      2
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white truncate max-w-full">
                    {filteredStudents[1].name}
                  </h3>
                  <p className="text-sm text-gray-400 font-mono truncate">{filteredStudents[1].email}</p>
                </div>
                <div className="bg-gray-400/10 border border-gray-400/20 text-gray-300 rounded-2xl py-2 px-4 font-black text-2xl tracking-wide max-w-max mx-auto shadow-sm">
                  {filteredStudents[1].score} <span className="text-xs font-bold text-gray-400">نقطة</span>
                </div>
              </div>
            )}

            {/* 1st Place */}
            {filteredStudents[0] && (
              <div className="bg-zinc-900/80 border-2 border-amber-500/50 rounded-[2.5rem] p-8 text-center order-1 md:order-2 relative shadow-[0_0_40px_rgba(245,158,11,0.15)] md:h-[300px] flex flex-col justify-between overflow-hidden">
                <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-amber-500 to-yellow-400" />
                <div className="absolute -top-3 -right-3 rotate-12">
                  <Award className="w-16 h-16 text-amber-400 drop-shadow-[0_0_15px_rgba(245,158,11,0.5)] animate-bounce" />
                </div>
                <div>
                  <div className="relative w-24 h-24 mx-auto mb-4">
                    {filteredStudents[0].photo ? (
                      <img
                        src={filteredStudents[0].photo}
                        alt={filteredStudents[0].name}
                        className="w-full h-full rounded-3xl object-cover border-4 border-amber-400"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full rounded-3xl bg-zinc-800 flex items-center justify-center border-4 border-amber-400">
                        <User className="w-12 h-12 text-amber-400" />
                      </div>
                    )}
                    <span className="absolute -bottom-2 -left-2 bg-amber-400 text-black font-black text-base w-9 h-9 rounded-xl flex items-center justify-center shadow-lg border-2 border-black">
                      1
                    </span>
                  </div>
                  <h3 className="text-2xl font-black text-white truncate max-w-full">
                    {filteredStudents[0].name}
                  </h3>
                  <p className="text-sm text-amber-400/80 font-mono truncate">{filteredStudents[0].email}</p>
                </div>
                <div className="bg-amber-400/15 border-2 border-amber-400/30 text-amber-400 rounded-3xl py-2 px-6 font-black text-3xl tracking-wide max-w-max mx-auto shadow-md">
                  {filteredStudents[0].score} <span className="text-sm font-bold">نقطة</span>
                </div>
              </div>
            )}

            {/* 3rd Place */}
            {filteredStudents[2] && (
              <div className="bg-zinc-900/60 border border-zinc-700/50 rounded-[2.5rem] p-6 text-center order-3 relative shadow-2xl h-[240px] flex flex-col justify-between overflow-hidden">
                <div className="absolute top-0 inset-x-0 h-1.5 bg-amber-700" />
                <div>
                  <div className="relative w-16 h-16 mx-auto mb-3">
                    {filteredStudents[2].photo ? (
                      <img
                        src={filteredStudents[2].photo}
                        alt={filteredStudents[2].name}
                        className="w-full h-full rounded-2xl object-cover border-2 border-amber-700"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full rounded-2xl bg-zinc-800 flex items-center justify-center border-2 border-amber-700">
                        <User className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                    <span className="absolute -bottom-2 -left-2 bg-amber-700 text-white font-extrabold text-xs w-6 h-6 rounded-lg flex items-center justify-center shadow-md">
                      3
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-white truncate max-w-full">
                    {filteredStudents[2].name}
                  </h3>
                  <p className="text-xs text-gray-400 font-mono truncate">{filteredStudents[2].email}</p>
                </div>
                <div className="bg-amber-700/10 border border-amber-700/20 text-amber-600 rounded-2xl py-1.5 px-4 font-black text-xl tracking-wide max-w-max mx-auto shadow-sm">
                  {filteredStudents[2].score} <span className="text-xs font-bold text-gray-400">نقطة</span>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {/* Main List Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-zinc-900/80 border border-white/10 rounded-[2rem] overflow-hidden shadow-2xl"
          dir="rtl"
        >
          {isLoading ? (
            <div className="py-20 text-center text-gray-400 font-medium">
              جاري تحميل لوحة الشرف... 🧪
            </div>
          ) : filteredStudents.length === 0 ? (
            <div className="py-20 text-center text-gray-400 font-medium">
              {search ? "لم نجد أي نتائج للبحث!" : "لا يوجد طلاب في لوحة الشرف حالياً!"}
            </div>
          ) : (
            <div className="divide-y divide-white/5">
              {/* Table Header */}
              <div className="grid grid-cols-12 gap-2 px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-500 text-right bg-black/40">
                <div className="col-span-2 text-center">الترتيب</div>
                <div className="col-span-5 sm:col-span-6 pr-4">الطالب</div>
                <div className="col-span-3 sm:col-span-2 text-center">الاحصائيات</div>
                <div className="col-span-2 text-left pl-4">النقاط</div>
              </div>

              {/* Rows */}
              {filteredStudents.map((student, index) => {
                const rank = students.findIndex((s) => s.email === student.email) + 1;
                const accuracy = student.totalAnswers > 0
                  ? Math.round((student.correctAnswersCount / student.totalAnswers) * 100)
                  : 0;

                return (
                  <motion.div
                    key={student.email}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: Math.min(0.5, index * 0.05) }}
                    className={`grid grid-cols-12 gap-2 items-center px-6 py-4 transition-colors hover:bg-white/5 ${
                      rank === 1
                        ? "bg-amber-500/5 hover:bg-amber-500/10"
                        : rank === 2
                        ? "bg-gray-400/5 hover:bg-gray-400/10"
                        : rank === 3
                        ? "bg-amber-700/5 hover:bg-amber-700/10"
                        : ""
                    }`}
                  >
                    {/* Rank */}
                    <div className="col-span-2 flex justify-center">
                      {rank === 1 ? (
                        <div className="bg-amber-400 text-black font-black w-8 h-8 rounded-xl flex items-center justify-center shadow-lg border border-yellow-300">
                          1
                        </div>
                      ) : rank === 2 ? (
                        <div className="bg-gray-400 text-black font-black w-8 h-8 rounded-xl flex items-center justify-center shadow-lg">
                          2
                        </div>
                      ) : rank === 3 ? (
                        <div className="bg-amber-700 text-white font-black w-8 h-8 rounded-xl flex items-center justify-center shadow-lg">
                          3
                        </div>
                      ) : (
                        <span className="text-gray-400 font-bold font-mono text-lg">{rank}</span>
                      )}
                    </div>

                    {/* Student Info */}
                    <div className="col-span-5 sm:col-span-6 flex items-center gap-3 pr-4 min-w-0">
                      <div className="w-10 h-10 rounded-xl overflow-hidden bg-zinc-800 flex-shrink-0 border border-white/10">
                        {student.photo ? (
                          <img src={student.photo} alt={student.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-500">
                            <User className="w-5 h-5" />
                          </div>
                        )}
                      </div>
                      <div className="truncate">
                        <h4 className="font-bold text-white text-base truncate">{student.name}</h4>
                        <p className="text-xs text-gray-500 font-mono truncate">{student.email}</p>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="col-span-3 sm:col-span-2 flex justify-around items-center gap-2">
                      {/* Streak */}
                      {student.consecutiveCorrect > 0 && (
                        <div className="flex items-center gap-1 bg-amber-500/15 border border-amber-500/20 text-amber-500 px-2.5 py-1 rounded-xl text-xs font-black shadow-sm animate-pulse">
                          <Flame className="w-4 h-4 fill-amber-500" />
                          <span className="font-mono">{student.consecutiveCorrect}</span>
                        </div>
                      )}

                      {/* Accuracy */}
                      <div className="hidden sm:flex items-center gap-1.5 text-xs text-gray-400 font-medium">
                        <Target className="w-4 h-4 text-emerald-500" />
                        <span>%{accuracy}</span>
                      </div>
                    </div>

                    {/* All-time score */}
                    <div className="col-span-2 text-left pl-4 font-black text-xl text-white tracking-wide font-mono">
                      {student.score}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
