import { Link } from "wouter";
import { motion } from "framer-motion";
import { GraduationCap, FlaskConical, ShieldCheck, Trophy } from "lucide-react";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { BigButton } from "@/components/BigButton";
import { Helmet } from "react-helmet-async";

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <Helmet>
        <title>كيمياء مستر أحمد - الصفحة الرئيسية</title>
        <meta name="description" content="البوابة الرسمية لكويزات وألعاب مادة الكيمياء مع مستر أحمد عبد الوهاب. تفاعل ممتع وسهل لجميع الطلاب." />
        <meta property="og:title" content="كيمياء مستر أحمد - الصفحة الرئيسية" />
        <meta property="og:description" content="البوابة الرسمية لكويزات وألعاب مادة الكيمياء مع مستر أحمد عبد الوهاب. تفاعل ممتع وسهل لجميع الطلاب." />
      </Helmet>
      <AnimatedBackground />

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="text-center mb-12 z-10"
      >
        <h1 className="text-5xl md:text-8xl mb-4 font-black tracking-tighter bg-gradient-to-r from-cyan-400 via-violet-400 to-emerald-400 bg-clip-text text-transparent drop-shadow-[0_4px_30px_rgba(6,182,212,0.3)] select-none">
          مرحباً طلاب مستر أحمد
        </h1>
        <p className="text-xl md:text-3xl text-gray-400 max-w-2xl mx-auto font-medium leading-relaxed tracking-tight opacity-90">
          تجربة كويز ممتعة وتفاعلية في الفصل للجميع!
        </p>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2, duration: 0.6, ease: "easeOut" }}
        className="flex flex-col md:grid md:grid-cols-4 gap-6 md:gap-6 z-10 w-full max-w-7xl px-4"
      >
        <Link href="/student/join" className="contents">
          <motion.div 
            whileHover={{ scale: 1.05, y: -5 }} 
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
            className="order-1 flex w-full h-full"
          >
            <BigButton
              label="أنا طالب"
              sublabel="سجل دخولك وانضم للمتعة!"
              variant="secondary"
              size="xl"
              icon={<FlaskConical className="w-16 h-16 mb-2" />}
              className="h-full min-h-[16rem] md:h-80 shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:shadow-secondary/30 border-b-8 active:border-b-0 transition-all rounded-[2.5rem] text-2xl md:text-3xl w-full"
            />
          </motion.div>
        </Link>

        <Link href="/teacher/login" className="contents">
          <motion.div 
            whileHover={{ scale: 1.05, y: -5 }} 
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
            className="order-2 flex w-full h-full"
          >
            <BigButton
              label="أنا معلم"
              sublabel="أنشئ كويزات وتابع الدرجات"
              variant="primary"
              size="xl"
              icon={<GraduationCap className="w-16 h-16 mb-2" />}
              className="h-full min-h-[16rem] md:h-80 shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:shadow-primary/30 border-b-8 active:border-b-0 transition-all rounded-[2.5rem] text-2xl md:text-3xl w-full"
            />
          </motion.div>
        </Link>
        
        <Link href="/host/login" className="contents">
          <motion.div 
            whileHover={{ scale: 1.05, y: -5 }} 
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
            className="order-3 flex w-full h-full"
          >
            <BigButton
              label="أنا المضيف"
              sublabel="راقب حالة الكويز مباشرة"
              variant="accent"
              size="xl"
              icon={<ShieldCheck className="w-16 h-16 mb-2" />}
              className="h-full min-h-[16rem] md:h-80 shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:shadow-accent/30 border-b-8 active:border-b-0 transition-all rounded-[2.5rem] text-2xl md:text-3xl w-full"
              data-testid="link-host-login"
            />
          </motion.div>
        </Link>

        <Link href="/leaderboard" className="contents">
          <motion.div 
            whileHover={{ scale: 1.05, y: -5 }} 
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
            className="order-4 flex w-full h-full"
          >
            <BigButton
              label="الترتيب والنقاط"
              sublabel="لوحة الشرف وتراكم نقاط العام"
              variant="gold"
              size="xl"
              icon={<Trophy className="w-16 h-16 mb-2" />}
              className="h-full min-h-[16rem] md:h-80 shadow-[0_20px_50px_rgba(0,0,0,0.3)] hover:shadow-amber-500/30 border-b-8 active:border-b-0 transition-all rounded-[2.5rem] text-2xl md:text-3xl w-full"
            />
          </motion.div>
        </Link>
      </motion.div>

      <motion.footer 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="absolute bottom-4 text-sm text-gray-600 font-mono"
      >
      </motion.footer>
    </div>
  );
}
