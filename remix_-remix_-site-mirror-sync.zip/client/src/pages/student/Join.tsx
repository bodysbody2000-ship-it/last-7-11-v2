import { useEffect, useRef, useState } from "react";
import { useStudentJoin } from "@/hooks/use-students";
import { AnimatedBackground } from "@/components/AnimatedBackground";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, FlaskConical, User, ShieldCheck, Camera, RefreshCw, Download, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet-async";

function InstallPrompt({ onAccept, onDismiss }: { onAccept: () => void; onDismiss: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
    >
      <motion.div
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 80, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 28 }}
        className="relative w-full max-w-sm bg-zinc-900 border border-white/10 rounded-3xl p-6 shadow-2xl text-center"
        dir="rtl"
      >
        <button
          onClick={onDismiss}
          className="absolute top-4 left-4 text-white/40 hover:text-white/80 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-16 h-16 rounded-2xl overflow-hidden mx-auto mb-4 shadow-lg border border-white/10">
          <img src="/logo.png" alt="App Icon" className="w-full h-full object-cover" />
        </div>

        <h2 className="text-white text-xl font-bold mb-1">أضف التطبيق للشاشة الرئيسية</h2>
        <p className="text-gray-400 text-sm mb-6 leading-relaxed">
          وصّل للكويز بسرعة من أيقونة على الموبايل أو الكمبيوتر بتاعك
        </p>

        <div className="flex gap-3">
          <button
            onClick={onDismiss}
            className="flex-1 py-3 rounded-2xl border border-white/10 text-white/60 font-semibold text-sm hover:bg-white/5 transition-colors"
          >
            مش دلوقتي
          </button>
          <button
            onClick={onAccept}
            className="flex-1 py-3 rounded-2xl bg-primary text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors"
          >
            <Download className="w-4 h-4" />
            تثبيت
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function CameraCapture({ studentId, onDone }: { studentId: string; onDone: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [captured, setCaptured] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [cameraError, setCameraError] = useState(false);

  useEffect(() => {
    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: "user" }, audio: false })
      .then((s) => {
        setStream(s);
        if (videoRef.current) {
          videoRef.current.srcObject = s;
        }
      })
      .catch(() => setCameraError(true));

    return () => {
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const capture = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement("canvas");
    const maxW = 240;
    const ratio = (videoRef.current.videoHeight || 180) / (videoRef.current.videoWidth || 240);
    canvas.width = maxW;
    canvas.height = Math.round(maxW * ratio);
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.scale(-1, 1);
      ctx.drawImage(videoRef.current, -canvas.width, 0, canvas.width, canvas.height);
    }
    const photo = canvas.toDataURL("image/jpeg", 0.4);
    setCaptured(photo);
    stream?.getTracks().forEach((t) => t.stop());
  };

  const retake = () => {
    setCaptured(null);
    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: "user" }, audio: false })
      .then((s) => {
        setStream(s);
        if (videoRef.current) videoRef.current.srcObject = s;
      })
      .catch(() => setCameraError(true));
  };

  const upload = async () => {
    if (!captured) return;
    setUploading(true);
    try {
      await fetch(`/api/students/${studentId}/photo`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ photo: captured }),
      });
      localStorage.setItem("studentPhoto", captured);
    } catch {}
    setUploading(false);
    onDone();
  };

  if (cameraError) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-zinc-900/90 rounded-3xl p-8 shadow-2xl border border-white/10 text-center"
      >
        <Camera className="w-16 h-16 mx-auto mb-4 text-gray-500" />
        <p className="text-white text-xl font-bold mb-2">تعذر الوصول للكاميرا</p>
        <p className="text-gray-400 mb-6">يمكنك المتابعة بدون صورة</p>
        <Button onClick={onDone} className="w-full h-14 bg-primary text-white rounded-2xl font-bold text-xl">
          متابعة بدون صورة
        </Button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-md bg-zinc-900/90 rounded-3xl p-6 shadow-2xl border border-white/10 text-center"
    >
      <div className="flex items-center justify-center gap-2 mb-4">
        <Camera className="w-6 h-6 text-primary" />
        <h2 className="text-2xl font-bold text-white">التقط صورتك</h2>
      </div>
      <p className="text-gray-400 text-sm mb-5">صورة سيلفي سريعة تظهر للمعلم 📸</p>

      <div className="relative rounded-2xl overflow-hidden bg-black mb-5 aspect-[4/3]">
        {!captured ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
            style={{ transform: "scaleX(-1)" }}
          />
        ) : (
          <img src={captured} alt="selfie" className="w-full h-full object-cover" />
        )}
      </div>

      {!captured ? (
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={capture}
          className="w-full h-14 bg-white text-black rounded-2xl font-bold text-xl shadow-xl flex items-center justify-center gap-3"
        >
          <Camera className="w-6 h-6" />
          التقط الصورة
        </motion.button>
      ) : (
        <div className="flex gap-3">
          <button
            onClick={retake}
            className="flex-1 h-14 bg-white/10 text-white rounded-2xl font-bold border border-white/20 flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            إعادة
          </button>
          <button
            onClick={upload}
            disabled={uploading}
            className="flex-1 h-14 bg-primary text-white rounded-2xl font-bold shadow-xl flex items-center justify-center gap-2"
          >
            {uploading ? "جاري الرفع..." : "تأكيد ✓"}
          </button>
        </div>
      )}

      <button onClick={onDone} className="mt-3 w-full text-gray-500 text-sm hover:text-gray-400 transition-colors">
        تخطي
      </button>
    </motion.div>
  );
}

export default function StudentJoin() {
  const join = useStudentJoin();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [showNameInput, setShowNameInput] = useState(false);
  // step: "form" → "rules" → "camera" → dashboard
  const [step, setStep] = useState<"form" | "rules" | "camera">("form");
  const [pendingStudentId, setPendingStudentId] = useState<string | null>(null);
  const [pendingName, setPendingName] = useState("");

  const [showInstallPrompt, setShowInstallPrompt] = useState(false);
  const deferredPrompt = useRef<any>(null);

  useEffect(() => {
    if (localStorage.getItem("installPromptDismissed")) return;

    const handler = (e: any) => {
      e.preventDefault();
      deferredPrompt.current = e;
      setTimeout(() => setShowInstallPrompt(true), 1200);
    };

    window.addEventListener("beforeinstallprompt", handler as any);
    return () => window.removeEventListener("beforeinstallprompt", handler as any);
  }, []);

  const handleInstallAccept = async () => {
    setShowInstallPrompt(false);
    localStorage.setItem("installPromptDismissed", "1");
    if (deferredPrompt.current) {
      deferredPrompt.current.prompt();
      await deferredPrompt.current.userChoice;
      deferredPrompt.current = null;
    }
  };

  const handleInstallDismiss = () => {
    setShowInstallPrompt(false);
    localStorage.setItem("installPromptDismissed", "1");
  };


  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const googleId = params.get("id");
    const googleName = params.get("name");
    const googlePhoto = params.get("photo");
    if (googleId && googleName) {
      localStorage.setItem("studentId", googleId);
      localStorage.setItem("studentName", googleName);
      // Save Google profile photo only if no selfie has been taken yet
      if (googlePhoto && !localStorage.getItem("studentPhoto")) {
        localStorage.setItem("studentPhoto", googlePhoto);
      }
      setPendingStudentId(googleId);
      setStep("rules");
      return;
    }

    if (!localStorage.getItem("googleNotified")) {
      localStorage.setItem("googleNotified", "1");
      setTimeout(() => {
        toast({
          title: "🎉 مرحباً!",
          description: "تم تفعيل تسجيل الدخول باستخدام جوجل",
          duration: 5000,
        });
      }, 800);
    }
  }, [toast]);

  const handleGoogleLogin = () => {
    window.location.href = "/auth/google";
  };

  // Name login: validate → show rules
  const handleManualJoin = () => {
    if (!name.trim()) {
      toast({ variant: "destructive", title: "خطأ", description: "يرجى إدخال الاسم" });
      return;
    }
    const validNameRegex = /^[A-Za-z0-9\s\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+$/;
    if (!validNameRegex.test(name.trim())) {
      toast({ variant: "destructive", title: "خطأ", description: "يرجى إدخال اسم صحيح (أحرف وأرقام ومسافات فقط)" });
      return;
    }
    setPendingName(name.trim());
    setStep("rules");
  };

  // After rules confirmed: join API (if name) or go straight to camera (if Google)
  const confirmJoin = async () => {
    if (pendingStudentId) {
      // Google flow — ID already known, go to camera
      setStep("camera");
      return;
    }
    try {
      const student = await join.mutateAsync({ name: pendingName });
      localStorage.setItem("studentId", String(student.id));
      localStorage.setItem("studentName", student.name);
      setPendingStudentId(String(student.id));
      setStep("camera");
    } catch (e: any) {
      toast({ 
        variant: "destructive", 
        title: "خطأ", 
        description: e?.message || "لا يمكن الانضمام حالياً (ربما الاسم مستخدم بالفعل)" 
      });
    }
  };

  // Camera step
  if (step === "camera" && pendingStudentId) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 relative">
        <AnimatedBackground />
        <CameraCapture
          studentId={pendingStudentId}
          onDone={() => setLocation("/student/dashboard")}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <Helmet>
        <title>انضم للكويز - كيمياء مستر أحمد</title>
        <meta name="description" content="سجل اسمك أو ادخل بحساب جوجل الخاص بك للانضمام لكويزات كيمياء مستر أحمد عبد الوهاب التفاعلية مباشرة." />
        <meta property="og:title" content="انضم للكويز - كيمياء مستر أحمد" />
        <meta property="og:description" content="سجل اسمك أو ادخل بحساب جوجل الخاص بك للانضمام لكويزات كيمياء مستر أحمد عبد الوهاب التفاعلية مباشرة." />
      </Helmet>
      <AnimatedBackground />

      <AnimatePresence>
        {showInstallPrompt && (
          <InstallPrompt onAccept={handleInstallAccept} onDismiss={handleInstallDismiss} />
        )}
      </AnimatePresence>

      <Link href="/" className="absolute top-4 left-4 md:top-8 md:left-8 p-2 rounded-full hover:bg-black/5 transition-colors">
        <ArrowLeft className="w-6 h-6 text-foreground/70" />
      </Link>

      <AnimatePresence mode="wait">
        {step === "form" ? (
          <motion.div
            key="join-form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full max-w-md bg-zinc-900/80 backdrop-blur-xl rounded-3xl p-5 sm:p-8 shadow-2xl border border-white/10 text-center"
          >
            <div className="text-center mb-5 sm:mb-8 space-y-2 sm:space-y-4">
              <div className="w-14 h-14 sm:w-20 sm:h-20 bg-primary/20 rounded-2xl flex items-center justify-center mx-auto text-primary">
                <FlaskConical className="w-8 h-8 sm:w-12 sm:h-12" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-display text-white font-bold">Lab Access</h2>
              <p className="text-gray-400 text-sm sm:text-base">انضم للحصة الآن</p>
            </div>

            <div className="space-y-3 sm:space-y-4">
              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleGoogleLogin}
                className="w-full py-3 sm:py-5 bg-white text-black rounded-2xl font-bold text-lg sm:text-2xl shadow-2xl hover:shadow-white/10 transition-all flex items-center justify-center gap-3 sm:gap-4"
              >
                <img src="https://www.google.com/favicon.ico" className="w-5 h-5 sm:w-7 sm:h-7" alt="Google" />
                دخول بحساب Google
              </motion.button>

              <div className="relative py-3">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-white/10" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-zinc-900 px-3 text-gray-500 font-bold tracking-widest">أو</span>
                </div>
              </div>

              <AnimatePresence>
                {!showNameInput ? (
                  <motion.div
                    key="name-btn"
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0, height: 0 }}
                  >
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        onClick={() => setShowNameInput(true)}
                        variant="outline"
                        className="w-full h-12 sm:h-14 border-white/20 text-white bg-white/5 hover:bg-white/10 rounded-2xl font-bold text-lg sm:text-xl flex items-center justify-center gap-3"
                      >
                        <User className="w-5 h-5 sm:w-6 sm:h-6" />
                        دخول بالاسم
                      </Button>
                    </motion.div>
                    <p className="text-zinc-500 text-xs mt-2" dir="rtl">
                      ⚠️ الدخول بالاسم لا يحفظ نقاطك بشكل دائم طوال العام (يفضل حساب جوجل)
                    </p>
                  </motion.div>
                ) : (
                  <motion.div
                    key="name-input"
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-3"
                  >
                    <Input
                      placeholder="أدخل اسمك هنا..."
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleManualJoin()}
                      autoFocus
                      className="h-12 sm:h-14 bg-white/5 border-white/10 text-white text-center text-lg sm:text-xl rounded-2xl focus:ring-2 focus:ring-primary/50 transition-all"
                    />
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        onClick={handleManualJoin}
                        disabled={join.isPending}
                        className="w-full h-12 sm:h-14 bg-primary hover:bg-primary/90 text-white rounded-2xl font-bold text-lg sm:text-xl shadow-xl"
                      >
                        <User className="ml-3 w-5 h-5 sm:w-6 sm:h-6" />
                        دخول بالاسم
                      </Button>
                    </motion.div>
                    <p className="text-amber-400 text-xs font-semibold mt-1" dir="rtl">
                      ⚠️ تنبيه: نقاطك لن تُحفظ بشكل دائم طوال السنة إلا بتسجيل الدخول بجوجل
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="mt-6 p-3 bg-primary/10 border border-primary/20 rounded-xl text-xs text-primary/90 leading-relaxed">
              Don't forget to subscribe to Mr.Ahmed channel on youtube (chemistry worled)
            </div>

          </motion.div>
        ) : step === "rules" ? (
          <motion.div
            key="rules"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-lg bg-black rounded-3xl p-5 sm:p-8 shadow-2xl border-2 border-primary/30 text-right"
            dir="rtl"
          >
            <div className="flex items-center justify-center gap-3 mb-6 text-primary">
              <ShieldCheck className="w-8 h-8 sm:w-10 sm:h-10 flex-shrink-0" />
              <h2 className="text-2xl sm:text-3xl font-bold">قوانين المختبر 🧪</h2>
            </div>

            <div className="space-y-5 text-white text-base sm:text-lg leading-relaxed mb-8">
              <p className="font-bold text-base sm:text-xl text-white bg-zinc-900 p-3 sm:p-4 rounded-2xl border border-white/10">
                اللعبه لعبه دقه وسرعه وعلشان كده احنا خلينا الطالب الاول اللي هيجاوب صح هياخد 10 نقط والتاني هياخد 9 الثالث هياخد 8 وهكذا.
              </p>
              <div className="bg-primary/10 p-4 rounded-2xl border border-primary/20 space-y-3 text-sm text-right">
                <p className="text-primary font-bold">⚠️ قواعد هامة للنقاط:</p>
                <ul className="space-y-2 text-gray-300">
                  <li>• في حالة استخدام زر <span className="text-primary font-bold">try again</span>: إذا جاوبت صح هتاخد <span className="text-green-400 font-bold">3 نقط</span>، ولو جاوبت غلط تنقص <span className="text-red-400 font-bold">5 نقط</span>.</li>
                  <li>• إذا جاوبت <span className="text-yellow-400 font-bold">4 مرات صح ورا بعض (4 streak)</span>: هتاخد <span className="text-yellow-400 font-bold">double score</span> في السؤال الرابع!</li>
                  <li>• المحاولة الأولى الخاطئة <span className="text-blue-400 font-bold">لا خصم فيها</span>، الخصم يبدأ من المحاولة الثانية.</li>
                </ul>
              </div>
              <div className="bg-green-500/10 p-4 rounded-2xl border border-green-500/30 text-sm text-green-300 leading-relaxed break-words">
                <p className="font-bold text-green-400 mb-1">📧 ملاحظة:</p>
                <p>إذا دخلت بحساب Google سيتم ارسال جميع التحديثات عبر ال e-mail</p>
              </div>
              <ul className="space-y-2 text-xs text-gray-400">
                <li>• تأكد من استقرار الإنترنت لديك.</li>
                <li>• لا تغلق الصفحة أثناء الاختبار.</li>
              </ul>
            </div>

            <Button
              onClick={confirmJoin}
              className="w-full h-16 bg-green-500 hover:bg-green-600 text-white rounded-2xl font-bold text-2xl shadow-[0_0_20px_rgba(34,197,94,0.3)] transition-all animate-pulse"
            >
              موافق، ابدأ الآن! 🚀
            </Button>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}
